#ifndef DEBUG_H
# define DEBUG_H

extern int this_is_center;

# endif